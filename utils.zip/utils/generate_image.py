import os
import uuid
from PIL import Image
import torch
from diffusers import StableDiffusionPipeline
from .style_transfer import apply_style_transfer
from openai import OpenAI
from dotenv import load_dotenv

# Ortam değişkenlerini yükle (.env içinden API anahtarları)
load_dotenv()

HF_TOKEN = os.getenv("HF_TOKEN")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# OpenAI istemcisi (GPT kullanmak için)
client = OpenAI(api_key=OPENAI_API_KEY)

# 🧠 GPT-4 Turbo ile betimleyici çizim prompt'u üret
def get_drawing_prompt(emotional_text):
    """
    Kullanıcının verdiği duygusal metni daha detaylı, çizime uygun bir betimlemeye dönüştürür.

    Args:
        emotional_text (str): Kısa duygusal cümle
    Returns:
        str: Stable Diffusion için uygun hale getirilmiş uzun betimleyici prompt
    """
    system_prompt = "Sen bir sanat yönetmenisin. Kullanıcının verdiği duygusal cümleyi, görselleştirilebilecek şekilde detaylı bir İngilizce çizim açıklamasına çevir."
    
    completion = client.chat.completions.create(
        model="gpt-4-turbo",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": emotional_text}
        ],
        temperature=0.7
    )
    
    drawing_prompt = completion.choices[0].message.content.strip()
    return drawing_prompt

# 🎨 Stable Diffusion modelini sadece bir kez yükle
pipe = StableDiffusionPipeline.from_pretrained(
    "runwayml/stable-diffusion-v1-5",
    use_auth_token=HF_TOKEN,
    torch_dtype=torch.float32
).to("cuda" if torch.cuda.is_available() else "cpu")

def generate_image_from_text(emotional_text, artist_name):
    """
    Kullanıcının verdiği duygusal metni önce betimleyici hale getirir,
    sonra SD ile görsel üretir ve stil dönüşümü uygular.

    Args:
        emotional_text (str): Duygusal metin (örneğin "yağmurda yürüyen yalnız bir çocuk")
        artist_name (str): Stil dönüşümü yapılacak sanatçı ("monet", "vangogh", "munch")

    Returns:
        str: Stil dönüşümü uygulanmış görselin dosya yolu
    """

    # 🧠 Adım 1: GPT ile betimleyici prompt üret
    prompt = get_drawing_prompt(emotional_text)
    print(f"🎯 GPT'den gelen çizim prompt'u: {prompt}")

    # 🖼️ Adım 2: SD ile görsel üret
    unique_name = f"{uuid.uuid4().hex}_original.png"
    output_path = os.path.join("static/uploads", unique_name)

    image = pipe(prompt).images[0]
    image.save(output_path)
    print(f"✅ Görsel üretildi ve kaydedildi: {output_path}")

    # 🎨 Adım 3: Stil dönüşümü uygula
    styled_path = apply_style_transfer(output_path, artist_name)
    return styled_path
