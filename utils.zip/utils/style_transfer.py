import os
import shutil
import uuid
import subprocess
import glob

def apply_style_transfer(input_image_path, artist_name):
    """
    Verilen görseli istenilen sanatçının stiline dönüştürür.

    Args:
        input_image_path (str): Yüklenen orijinal görselin yolu
        artist_name (str): "monet", "vangogh" ya da "munch"

    Returns:
        str: Çıktı görselinin dosya yolu (Flask için gösterilecek)
    """

    # 🔧 Yol ayarları
    base_model_path = f"./models/{artist_name}"
    test_script = os.path.join(base_model_path, "test.py")
    testA_path = os.path.join(base_model_path, "datasets/testA")
    results_path = os.path.join("./results", f"cut_{artist_name}_final", "test_latest", "images", "fake_B")

    
    # 🔄 testA klasörünü sıfırla
    if os.path.exists(testA_path):
       for f in os.listdir(testA_path):
           os.remove(os.path.join(testA_path, f))


    # 📤 Kullanıcının görselini testA klasörüne kopyala (benzersiz isim ver)
    filename = f"{uuid.uuid4().hex}.png"
    test_image_path = os.path.join(testA_path, filename)
    shutil.copy(input_image_path, test_image_path)

    # ▶️ Stil dönüşümünü çalıştır
    command = [
        "python", test_script,
        "--dataroot", os.path.join(base_model_path, "datasets"),
        "--name", f"cut_{artist_name}_final",
        "--model", "cut",
        "--phase", "test",
        "--no_dropout",
        "--epoch", "latest",
        "--num_test", "9999",
        "--preprocess", "resize_and_crop",
        "--load_size", "512",
        "--crop_size", "512"
    ]
    
    result = subprocess.run(command, capture_output=True, text=True)

    print("📤 Stil dönüşüm çıktısı:\n", result.stdout)
    print("❌ Stil dönüşüm hatası:\n", result.stderr)
     

    # ✅ Çıktı dosyasını otomatik bul
    png_files = glob.glob(os.path.join(results_path, "*.png"))
    if not png_files:
        raise FileNotFoundError(f"Çıktı görseli bulunamadı: {results_path} içinde .png dosyası yok.")
    output_image_source_path = png_files[0]

    # 🔄 Flask içinde gösterebilmek için static klasörüne kopyala
    output_unique_name = f"{uuid.uuid4().hex}_{artist_name}.png"
    output_dest_path = os.path.join("static/outputs", output_unique_name)
    shutil.copy(output_image_source_path, output_dest_path)
    print(f"✅ Çıktı görseli {output_dest_path} olarak kaydedildi.")
    return output_dest_path
